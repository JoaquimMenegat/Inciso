# Inciso — identidade visual (handoff para Claude Code)

Plataforma de estudo de Direito. Slogan: **"Direto, incisivo."** Conceito: inciso = item numerado de um artigo ("I –", "II –").

## Arquivos
- `Inciso Identidade.dc.html` — brand book: logos (3 caminhos), abertura animada, ícone/favicon, cores, padrão, selo, ícones, marcadores, aplicações (capa de aula, card de progresso, post, telas do app claro/escuro). Abrir no navegador; o markup é a referência visual.
- `Inciso Guia de Movimento.dc.html` — regras de animação.
- `IncisoSelo.dc.html` — selo circular reutilizável (SVG + textPath). Props: text, center, color, ink, outline, spin, period.
- `inciso-motion.js` — motor de animação (Web Animations API). `IncisoMotion.play(root)`, `.observe(root)`, `.spin(el, s)`. Elementos com `data-a="draw|rise|up|fade|grow|stamp|letters|ring|count"` + `data-d` (delay ms) / `data-dur`. Respeita prefers-reduced-motion (HTML = estado final).
- `support.js` — runtime para abrir os .dc.html; não faz parte da marca.

## Tokens
```css
:root{
  --tinta:#1B2540; --selo:#A3263A; --latao:#B98A2E; --salvia:#4F7464;
  --papel:#EEF1F5; --folha:#FFFFFF; --texto-2:#59627A; --hairline:#C8CFDB;
  --ease-inciso:cubic-bezier(.2,.8,.2,1);
}
[data-theme=dark]{
  --bg:#131A2B; --superficie:#1B2540; --texto:#EEF1F5; --texto-2:#A3ADC2;
  --selo:#E0566B; --latao:#D9AE57; --salvia:#82B29B; --hairline:#2E3A58;
}
```
- Fontes (Google Fonts): Libre Caslon Text (títulos, marca, numerais romanos) + Archivo (interface).
- Cantos retos (radius 0), réguas de 2px em Tinta, alinhamento à esquerda.
- Vermelho só no selo e no que pede atenção; Sálvia só para progresso/acerto; Latão para travessões e numerais.
- Ícones: traço 1,5px, linecap square, grade 24 (SVGs no brand book).

## Movimento
Micro 120ms · Base 240 · Entrada 480 (sobe 16px) · Travessão 600 (scaleX da esquerda) · Carimbo 620 (escala 1.9→.92→1.05→.98→1.01→1, rotate -8°) · Subida mascarada 640 · Progresso 1400 · Abertura 3200 (só splash).
Um gesto de marca por vez; no máximo um carimbo por tela.

## Evitar
Balança, martelo, colunas, livros, louros, brasões, corujas, beca; degradês, 3D, sombras pesadas, mascotes.
